package myapp.mod5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usernameEditText, passwordEditText;
    Button loginButton, registerButton, continueButton; // Declare the continue button
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        continueButton = findViewById(R.id.continue_button); // Initialize continue button

        db = new DatabaseHelper(this);

        // Handle login button click
        loginButton.setOnClickListener(view -> {
            String user = usernameEditText.getText().toString().trim();
            String pass = passwordEditText.getText().toString().trim();

            // Validate user input (ensure both username and password are provided)
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
            } else if (db.checkUser(user, pass)) {
                // Login successful, navigate to next screen
                Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();

                // Intent to navigate to InventoryActivity (or the next activity)
                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                startActivity(intent);

                // Optionally finish MainActivity to prevent going back to login screen
                finish();
            } else {
                // Login failed, show a toast
                Toast.makeText(MainActivity.this, "Login failed. Check credentials.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle register button click
        registerButton.setOnClickListener(view -> {
            String user = usernameEditText.getText().toString().trim();
            String pass = passwordEditText.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                // Ensure both username and password are provided for registration
                Toast.makeText(MainActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
            } else if (db.userExists(user)) {
                // Check if the user already exists
                Toast.makeText(MainActivity.this, "User already exists!", Toast.LENGTH_SHORT).show();
            } else {
                boolean success = db.registerUser(user, pass);
                if (success) {
                    Toast.makeText(MainActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Registration failed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle continue button click (without login)
        continueButton.setOnClickListener(view -> {
            // Directly navigate to the InventoryActivity (or whichever activity is next)
            Toast.makeText(MainActivity.this, "Continuing without login.", Toast.LENGTH_SHORT).show();

            // Navigate to the InventoryActivity
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);

            // Optionally finish MainActivity to prevent going back to login screen
            finish();
        });
    }
}








