package myapp.mod5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.telephony.SmsManager;

import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AppDB.db";
    private static final int DATABASE_VERSION = 2;

    // User table
    private static final String USER_TABLE = "users";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Inventory table
    private static final String ITEM_TABLE = "inventory";
    private static final String COL_ID = "id";
    private static final String COL_ITEM_NAME = "item_name";
    private static final String COL_QUANTITY = "quantity";
    private static final String COL_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                COL_USERNAME + " TEXT PRIMARY KEY, " +
                COL_PASSWORD + " TEXT)");

        // Create Inventory table
        db.execSQL("CREATE TABLE " + ITEM_TABLE + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER, " +
                COL_DATE + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE);
        onCreate(db);
    }

    // User operations
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                        " WHERE " + COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        Log.d("DatabaseHelper", "Checking user: " + username + " | " + password + " | Found: " + exists);

        cursor.close();
        return exists;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                        " WHERE " + COL_USERNAME + " = ?",
                new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Inventory operations
    public void addItem(String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Normalize item name by trimming whitespace and converting to lowercase
        name = name.trim().toLowerCase();

        // Check if the item already exists in the inventory (normalized query)
        Cursor cursor = db.rawQuery("SELECT * FROM " + ITEM_TABLE + " WHERE LOWER(TRIM(" + COL_ITEM_NAME + ")) = ?", new String[]{name});

        if (cursor.moveToFirst()) {
            // Item exists, so update the quantity
            int currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_QUANTITY));
            int newQuantity = currentQuantity + quantity;

            ContentValues values = new ContentValues();
            values.put(COL_QUANTITY, newQuantity); // Update the quantity
            values.put(COL_DATE, date); // Update the date

            // Update the item in the database
            db.update(ITEM_TABLE, values, COL_ITEM_NAME + " = ?", new String[]{name});

            // Check if quantity is below threshold and send SMS if necessary
            if (newQuantity < 2) {
                sendLowStockAlert(name, newQuantity);
            }

            cursor.close();
        } else {
            // Item doesn't exist, so insert a new record
            ContentValues values = new ContentValues();
            values.put(COL_ITEM_NAME, name);
            values.put(COL_QUANTITY, quantity);
            values.put(COL_DATE, date);

            db.insert(ITEM_TABLE, null, values);// Insert into the inventory table
            cursor.close();

            // Check if quantity is below threshold and send SMS if necessary
            if (quantity < 2) {
                sendLowStockAlert(name, quantity);
            }

        }
    }

    public void deleteItem(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(ITEM_TABLE, COL_ITEM_NAME + " = ?", new String[]{name});
    }

    public ArrayList<HashMap<String, String>> getAllItems() {
        ArrayList<HashMap<String, String>> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + ITEM_TABLE, null);
        while (cursor.moveToNext()) {
            HashMap<String, String> item = new HashMap<>();
            item.put("name", cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME)));
            item.put("qty", cursor.getString(cursor.getColumnIndexOrThrow(COL_QUANTITY)));
            item.put("date", cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE)));
            itemList.add(item);
        }
        cursor.close();
        return itemList;
    }

    // Update only the date of a specific item
    public void updateItemDate(String name, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, newDate);

        db.update(ITEM_TABLE, values, COL_ITEM_NAME + " = ?", new String[]{name});
    }

    // Method to send SMS alert when stock is low
    private void sendLowStockAlert(String itemName, int quantity) {
        String message = "ALERT: The item '" + itemName + "' is low in stock. Only " + quantity + " left!";

        // Send the SMS (you'll need the proper permissions to send SMS)
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("+1YOUR_PHONE_NUMBER", null, message, null, null);

        // You can also trigger other forms of notification here (e.g., push notifications, dialog boxes)
    }
}