package myapp.mod5;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class InventoryActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1001;

    private TableLayout dataTable;
    private EditText itemInput;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        dataTable = findViewById(R.id.dataTable);
        itemInput = findViewById(R.id.itemEditText);
        Button addButton = findViewById(R.id.addButton);

        dbHelper = new DatabaseHelper(this);

        loadItemsFromDatabase();

        // Request SMS permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }

        addButton.setOnClickListener(v -> {
            String itemText = itemInput.getText().toString().trim();
            if (!itemText.isEmpty()) {
                String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                dbHelper.addItem(itemText, 1, currentDate);
                addRowToTable(itemText, "1", currentDate);
                itemInput.setText("");

                // Check SMS permission before sending
                if (ContextCompat.checkSelfPermission(InventoryActivity.this, Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    // Quantity threshold for testing
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(
                            "+15551234567", // Replace with real number for deployment
                            null,
                            "Alert: Inventory for '" + itemText + "' is low.",
                            null,
                            null);
                } else {
                    Toast.makeText(InventoryActivity.this, "SMS not sent. Permission not granted.", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(InventoryActivity.this, "Please enter an item.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied. SMS alerts disabled.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void loadItemsFromDatabase() {
        ArrayList<HashMap<String, String>> itemList = dbHelper.getAllItems();
        for (HashMap<String, String> item : itemList) {
            addRowToTable(item.get("name"), item.get("qty"), item.get("date"));
        }
    }

    private void addRowToTable(String name, String quantity, String date) {
        TableRow newRow = new TableRow(this);

        TextView itemTextView = new TextView(this);
        itemTextView.setText(name);
        itemTextView.setPadding(10, 10, 10, 10);

        TextView qtyTextView = new TextView(this);
        qtyTextView.setText(quantity);
        qtyTextView.setPadding(10, 10, 10, 10);

        TextView dateTextView = getTextView(name, date);

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setPadding(10, 10, 10, 10);
        deleteButton.setOnClickListener(v -> {
            dbHelper.deleteItem(name);
            dataTable.removeView(newRow);
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        newRow.addView(itemTextView);
        newRow.addView(qtyTextView);
        newRow.addView(dateTextView);
        newRow.addView(deleteButton);

        dataTable.addView(newRow);
    }

    private TextView getTextView(String name, String date) {
        TextView dateTextView = new TextView(this);
        dateTextView.setText(date);
        dateTextView.setPadding(10, 10, 10, 10);

        // Date editing with DatePicker
        dateTextView.setOnClickListener(v -> {
            Calendar.getInstance();
            String[] parts = dateTextView.getText().toString().split("-");
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]) - 1;
            int day = Integer.parseInt(parts[2]);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    InventoryActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String newDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                        dateTextView.setText(newDate);
                        dbHelper.updateItemDate(name, newDate);
                        Toast.makeText(this, "Date updated", Toast.LENGTH_SHORT).show();
                    },
                    year, month, day
            );
            datePickerDialog.show();
        });
        return dateTextView;
    }
}













